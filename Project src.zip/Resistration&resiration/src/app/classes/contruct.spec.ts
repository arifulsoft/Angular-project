import { Contruct } from './contruct';

describe('Contruct', () => {
  it('should create an instance', () => {
    expect(new Contruct()).toBeTruthy();
  });
});
