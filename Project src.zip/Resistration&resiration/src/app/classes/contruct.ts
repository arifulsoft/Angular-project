export class Contruct {
    id:any;
    name:any;
    email:any;
    password:any;
    constructor(  id:any,name:any,email:any, password:any){
        this.id=id
        this.name=name
        this.email=email
        this.password=password
    }
}
