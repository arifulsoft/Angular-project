export class Employe {
    empid:any;
    empname:any
    empemail:any
    emppassword:any
    constructor(  empid:any,empname:any, empemail:any,emppassword:any){
        this.empid=empid
        this.empname=empname
        this.empemail=empemail
        this.emppassword=emppassword
    }
}
