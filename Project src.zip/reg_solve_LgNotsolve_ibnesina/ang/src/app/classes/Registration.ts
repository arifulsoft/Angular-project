export class Registration {
   username:any;
   email:any;
   password:any;
   constructor(username:any,email:any,password:any){
    this.username=username;
    this.email=email;
    this.password=password;
   }

}
