import { AppointmentTable } from './appointment-table';

describe('AppointmentTable', () => {
  it('should create an instance', () => {
    expect(new AppointmentTable()).toBeTruthy();
  });
});
