import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contuct',
  templateUrl: './contuct.component.html',
  styleUrls: ['./contuct.component.css']
})
export class ContuctComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
