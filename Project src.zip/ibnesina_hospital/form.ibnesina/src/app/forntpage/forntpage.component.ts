import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-forntpage',
  templateUrl: './forntpage.component.html',
  styleUrls: ['./forntpage.component.css']
})
export class ForntpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
