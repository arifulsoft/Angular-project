import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-doctorname',
  templateUrl: './doctorname.component.html',
  styleUrls: ['./doctorname.component.css']
})
export class DoctornameComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
