import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-diagnasticservice',
  templateUrl: './diagnasticservice.component.html',
  styleUrls: ['./diagnasticservice.component.css']
})
export class DiagnasticserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
