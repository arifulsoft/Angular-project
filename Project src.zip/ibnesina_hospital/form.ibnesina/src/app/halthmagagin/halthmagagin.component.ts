import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-halthmagagin',
  templateUrl: './halthmagagin.component.html',
  styleUrls: ['./halthmagagin.component.css']
})
export class HalthmagaginComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
