import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hospitalservice',
  templateUrl: './hospitalservice.component.html',
  styleUrls: ['./hospitalservice.component.css']
})
export class HospitalserviceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
