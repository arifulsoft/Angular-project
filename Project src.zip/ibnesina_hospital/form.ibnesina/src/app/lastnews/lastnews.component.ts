import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lastnews',
  templateUrl: './lastnews.component.html',
  styleUrls: ['./lastnews.component.css']
})
export class LastnewsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
