import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bord',
  templateUrl: './bord.component.html',
  styleUrls: ['./bord.component.css']
})
export class BordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
