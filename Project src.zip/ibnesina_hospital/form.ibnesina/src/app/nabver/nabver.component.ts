import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nabver',
  templateUrl: './nabver.component.html',
  styleUrls: ['./nabver.component.css']
})
export class NabverComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
