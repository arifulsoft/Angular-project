import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-branchwaisedoctor',
  templateUrl: './branchwaisedoctor.component.html',
  styleUrls: ['./branchwaisedoctor.component.css']
})
export class BranchwaisedoctorComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
