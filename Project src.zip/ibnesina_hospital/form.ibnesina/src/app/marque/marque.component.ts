import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-marque',
  templateUrl: './marque.component.html',
  styleUrls: ['./marque.component.css']
})
export class MarqueComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
