export class Appointment {
    a_id: any;
    p_name: any;
    date: any;
    phone: any;
    problem: any;
    dept_name: any;
    email: any;
    d_id:any;

    constructor(a_id: any, p_name: any, date: any, phone: any, problem: any, dept_name: any, email: any,d_id:any) {
        this.a_id = a_id;
        this.p_name = p_name;
        this.date = date;
        this.phone = phone;
        this.problem = problem;
        this.dept_name = dept_name;
        this.email = email;
        this.d_id=d_id;

    }
}
