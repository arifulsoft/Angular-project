import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fornt',
  templateUrl: './fornt.component.html',
  styleUrls: ['./fornt.component.css']
})
export class ForntComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
