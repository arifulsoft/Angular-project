import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cartpic',
  templateUrl: './cartpic.component.html',
  styleUrls: ['./cartpic.component.css']
})
export class CartpicComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
