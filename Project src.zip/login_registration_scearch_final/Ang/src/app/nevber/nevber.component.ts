import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nevber',
  templateUrl: './nevber.component.html',
  styleUrls: ['./nevber.component.css']
})
export class NevberComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
