export class Post {
    userId:any;
    id:any;
    title:any;
    body:any;
    constructor(userId:any,id:any,title:any,body:any){
        this.userId=userId;
        this.id=id;
        this.title=title;
        this.body=body;
    }
}
