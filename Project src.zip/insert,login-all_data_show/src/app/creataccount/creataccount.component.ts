import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creataccount',
  templateUrl: './creataccount.component.html',
  styleUrls: ['./creataccount.component.css']
})
export class CreataccountComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
