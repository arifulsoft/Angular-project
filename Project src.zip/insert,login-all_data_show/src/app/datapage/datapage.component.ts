import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-datapage',
  templateUrl: './datapage.component.html',
  styleUrls: ['./datapage.component.css']
})
export class DatapageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
