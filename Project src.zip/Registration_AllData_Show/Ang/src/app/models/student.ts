export class Student {
  id:any;
  name:any;
  email:any;
  round:any;
  constructor(id:any,name:any,email:any,round:any){
    this.id=id;
    this.name=name;
    this.email=email;
    this.round=round;
  }
}
